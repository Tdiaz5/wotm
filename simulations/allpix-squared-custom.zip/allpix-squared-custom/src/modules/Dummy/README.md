# Dummy
**Maintainer**: *NAME* (*EMAIL*)  
**Status**: Functional  
[**Input**: *INPUT_MESSAGE*]  
[**Output**: *OUTPUT_MESSAGE*]  

### Description
*Short description of this module*

### Parameters
* `param`: *explanation with optional default*

### Usage
*Example how to use this module*
