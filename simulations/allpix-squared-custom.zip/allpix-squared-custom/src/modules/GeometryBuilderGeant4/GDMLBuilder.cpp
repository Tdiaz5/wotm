/**
 * @file
 * @brief Implements the Geant4 passive material construction process
 * @remarks Code is based on code from Mathieu Benoit
 * @copyright Copyright (c) 2017-2019 CERN and the Allpix Squared authors.
 * This software is distributed under the terms of the MIT License, copied verbatim in the file "LICENSE.md".
 * In applying this license, CERN does not waive the privileges and immunities granted to it by virtue of its status as an
 * Intergovernmental Organization or submit itself to any jurisdiction.
 */

#include "GDMLBuilder.hpp"
#include <memory>
#include <string>
#include <utility>

#include <Math/RotationX.h>
#include <Math/RotationY.h>
#include <Math/RotationZ.h>
#include <Math/RotationZYX.h>
#include <Math/Vector3D.h>

#include <G4Box.hh>
#include <G4IntersectionSolid.hh>
#include <G4Sphere.hh>
#include <G4SubtractionSolid.hh>
#include <G4Tubs.hh>
#include <G4UnionSolid.hh>

#include <G4AffineTransform.hh>
#include <G4LogicalVolume.hh>
#include <G4LogicalVolumeStore.hh>
#include <G4PVPlacement.hh>
#include <G4RotationMatrix.hh>
#include <G4ThreeVector.hh>
#include <G4VisAttributes.hh>
#include <G4VoxelLimits.hh>

#include "core/module/exceptions.h"
#include "tools/ROOT.h"
#include "tools/geant4.h"

using namespace allpix;
using namespace ROOT::Math;
GDMLBuilder::GDMLBuilder(G4VPhysicalVolume* daughter,
                         std::string construction_number,
                         Configuration& config,
                         GeometryManager* geo_manager)
    : daughter_(daughter), construction_number_(construction_number), config_(config), geo_manager_(geo_manager) {
    name_ = "GDML_Volume_" + construction_number_;
    position_ = daughter->GetObjectTranslation();
    global_translation_ = config_.get<XYZVector>("global_translation", XYZVector(0, 0, 0));
    if(global_translation_ != XYZVector(0, 0, 0)) {
        position_ += global_translation_;
    }
    rotWrapper_ = daughter->GetObjectRotation();
    log_volume_ = daughter->GetLogicalVolume();
}

/**
 * @brief Version of std::make_shared that does not delete the pointer
 *
 * This version is needed because some pointers are deleted by Geant4 internally, but they are stored as std::shared_ptr in
 * the framework.
 */
template <typename T, typename... Args> static std::shared_ptr<T> make_shared_no_delete(Args... args) {
    return std::shared_ptr<T>(new T(args...), [](T*) {});
}

void GDMLBuilder::build(std::map<std::string, G4Material*>) {
    /*
    Get the information for the passive materials
    */
    G4LogicalVolumeStore* log_volume_store = G4LogicalVolumeStore::GetInstance();
    auto mother_volume_ = config_.get<std::string>("mother_volume", "World");
    auto mother_log_volume = log_volume_store->GetVolume(mother_volume_);
    if(mother_log_volume == nullptr) {
        throw InvalidValueError(config_, "mother_volume", "mother_volume does not exist");
    }
    G4ThreeVector posWrapper = toG4Vector(position_);
    G4Transform3D transform_phys(*rotWrapper_, posWrapper);
    auto material = log_volume_->GetMaterial();

    LOG(INFO) << "Creating Geant4 model for '" << name_ << "' from GDML file";
    LOG(TRACE) << " -Material\t\t:\t " << material->GetName();
    LOG(TRACE) << " -Position\t\t:\t " << Units::display(position_, {"mm", "um"});

    auto gdml_log_vol = make_shared_no_delete<G4LogicalVolume>(log_volume_->GetSolid(), material, name_ + "_log");
    geo_manager_->setExternalObject("GDML_log", gdml_log_vol, name_);
    // Set colour to Red
    auto gdml_vol_vis = new G4VisAttributes(G4Colour(1, 0, 0, 0.6));
    gdml_log_vol->SetVisAttributes(gdml_vol_vis);

    // Place the physical volume of the passive material
    auto gdml_phys_vol = make_shared_no_delete<G4PVPlacement>(
        transform_phys, gdml_log_vol.get(), name_ + "_phys", mother_log_volume, false, 0, true);
    geo_manager_->setExternalObject("GDML_phys", gdml_phys_vol, name_);
    LOG(TRACE) << " Constructed GDML material " << name_ << " successfully";

    // Build all daughter volumes
    BuildDaughterVolumes(log_volume_, gdml_log_vol.get(), name_);
}

std::vector<XYZPoint> GDMLBuilder::addPoints() {
    std::array<int, 8> offset_x = {{1, 1, 1, 1, -1, -1, -1, -1}};
    std::array<int, 8> offset_y = {{1, 1, -1, -1, 1, 1, -1, -1}};
    std::array<int, 8> offset_z = {{1, -1, 1, -1, 1, -1, 1, -1}};
    // Caclulate minimal and maximal coordinates for the solids
    double minX, maxX, minY, maxY, minZ, maxZ;
    G4VoxelLimits limit;
    G4AffineTransform origin;
    log_volume_->GetSolid()->CalculateExtent(kXAxis, limit, origin, minX, maxX);
    log_volume_->GetSolid()->CalculateExtent(kYAxis, limit, origin, minY, maxY);
    log_volume_->GetSolid()->CalculateExtent(kYAxis, limit, origin, minZ, maxZ);
    auto max_size_x = std::max(std::abs(maxX), std::abs(minX));
    auto max_size_y = std::max(std::abs(maxY), std::abs(minY));
    auto max_size_z = std::max(std::abs(maxZ), std::abs(minZ));
    if(max_size_x == 0 || max_size_y == 0 || max_size_z == 0) {
        throw ModuleError("Pasive Material '" + name_ +
                          "' does not have a maximum size parameter associated with its model");
    }
    for(size_t i = 0; i < 8; ++i) {
        auto points_vector =
            G4ThreeVector(offset_x.at(i) * max_size_x, offset_y.at(i) * max_size_y, offset_z.at(i) * max_size_z);
        // Rotate the outer points of the material
        points_vector *= *rotWrapper_;
        points_.emplace_back(XYZPoint(
            position_.x() + points_vector.x(), position_.y() + points_vector.y(), position_.z() + points_vector.z()));
    }
    return points_;
}

void GDMLBuilder::BuildDaughterVolumes(G4LogicalVolume* volume, G4LogicalVolume* mother_volume, std::string name) const {
    // Place all the nested volumes
    auto n_daughters = volume->GetNoDaughters();
    for(int i = 0; i < n_daughters; i++) {
        auto n = std::to_string(i);
        auto nested_name = name + "_daughter_" + n;
        auto nested_phys = volume->GetDaughter(i);
        auto nested_position = nested_phys->GetObjectTranslation();
        auto nested_rotation = nested_phys->GetObjectRotation();
        G4Transform3D nested_transform_phys(*nested_rotation, nested_position);

        auto nested_log = nested_phys->GetLogicalVolume();
        auto material = nested_log->GetMaterial();

        LOG(TRACE) << "Creating Geant4 model for '" << nested_name << "' from GDML file";
        LOG(TRACE) << " -Material\t\t:\t " << material->GetName();
        LOG(TRACE) << " -Position\t\t:\t " << Units::display(nested_position, {"mm", "um"});

        auto nested_log_vol = make_shared_no_delete<G4LogicalVolume>(nested_log->GetSolid(), material, nested_name + "_log");
        geo_manager_->setExternalObject("GDML_log", nested_log_vol, nested_name);
        auto gdml_vol_vis = new G4VisAttributes(G4Colour(0.5, 0.5, 0, 0.4));
        nested_log_vol->SetVisAttributes(gdml_vol_vis);
        auto gdml_phys_vol = make_shared_no_delete<G4PVPlacement>(
            nested_transform_phys, nested_log_vol.get(), nested_name + "_phys", mother_volume, false, 0, true);
        geo_manager_->setExternalObject("GDML_phys", gdml_phys_vol, nested_name);
        LOG(TRACE) << " Constructed GDML material " << nested_name << " successfully";

        if(nested_log->GetNoDaughters() != 0) {
            BuildDaughterVolumes(nested_log, nested_log_vol.get(), nested_name);
        }
    }
}