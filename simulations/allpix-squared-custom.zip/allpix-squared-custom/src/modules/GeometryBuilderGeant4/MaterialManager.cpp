/**
 * @file
 * @brief Implementation of material manager for Geant4
 * @copyright Copyright (c) 2021 CERN and the Allpix Squared authors.
 * This software is distributed under the terms of the MIT License, copied verbatim in the file "LICENSE.md".
 * In applying this license, CERN does not waive the privileges and immunities granted to it by virtue of its status as an
 * Intergovernmental Organization or submit itself to any jurisdiction.
 */

#include "MaterialManager.hpp"

#include "core/module/exceptions.h"

using namespace allpix;

Materials& Materials::getInstance() {
    static Materials instance;
    return instance;
}

G4Material* Materials::get(const std::string& material) const {

    LOG(DEBUG) << "Searching for material \"" << material << "\"";
    // Look in our materials definitions
    // FIXME tolower for this comparison but not for the rest
    auto material_lower = material;
    std::transform(material_lower.begin(), material_lower.end(), material_lower.begin(), ::tolower);

    if(materials_.find(material_lower) != materials_.end()) {
        LOG(DEBUG) << "Found material \"" << material << "\" in internal database";
        return materials_.at(material_lower);
    }

    // If not found, try if we can get it from NIST manager:
    G4NistManager* nistman = G4NistManager::Instance();
    G4Material* nist_material = nullptr;

    // Make sure the material has the "G4_" prefix:
    std::string prefix = "G4_";
    auto res = std::mismatch(prefix.begin(), prefix.end(), material.begin());
    if(res.first == prefix.end()) {
        nist_material = nistman->FindOrBuildMaterial(material);
    } else {
        nist_material = nistman->FindOrBuildMaterial(prefix + material);
    }

    if(nist_material != nullptr) {
        LOG(DEBUG) << "Found material \"" << material << "\" in Geant4 NIST Database";
        return nist_material;
    }

    throw ModuleError("Could not find material with name \"" + material + "\"");
}

void Materials::set(const std::string& name, G4Material* material) {
    materials_.insert(std::make_pair(name, material));
}

/**
 * Initializes all the internal materials. The following materials are supported by this module:
 * - vacuum
 * - air
 * - silicon
 * - epoxy
 * - kapton
 * - solder
 * - CeBr3 scintillator
 */
void Materials::init_materials() {
    G4NistManager* nistman = G4NistManager::Instance();

    // Build table of materials from database
    materials_["silicon"] = nistman->FindOrBuildMaterial("G4_Si");
    materials_["plexiglass"] = nistman->FindOrBuildMaterial("G4_PLEXIGLASS");
    materials_["kapton"] = nistman->FindOrBuildMaterial("G4_KAPTON");
    materials_["copper"] = nistman->FindOrBuildMaterial("G4_Cu");
    materials_["aluminum"] = nistman->FindOrBuildMaterial("G4_Al");
    materials_["air"] = nistman->FindOrBuildMaterial("G4_AIR");
    materials_["lead"] = nistman->FindOrBuildMaterial("G4_Pb");
    materials_["tungsten"] = nistman->FindOrBuildMaterial("G4_W");

    // Create required elements:
    G4Element* H = new G4Element("Hydrogen", "H", 1., 1.01 * CLHEP::g / CLHEP::mole);
    G4Element* C = new G4Element("Carbon", "C", 6., 12.01 * CLHEP::g / CLHEP::mole);
    G4Element* O = new G4Element("Oxygen", "O", 8., 16.0 * CLHEP::g / CLHEP::mole);
    G4Element* Cl = new G4Element("Chlorine", "Cl", 17., 35.45 * CLHEP::g / CLHEP::mole);
    G4Element* Sn = new G4Element("Tin", "Sn", 50., 118.710 * CLHEP::g / CLHEP::mole);
    G4Element* Pb = new G4Element("Lead", "Pb", 82., 207.2 * CLHEP::g / CLHEP::mole);
    G4Element* Ce = new G4Element("Cerium", "Ce", 58., 140.12 * CLHEP::g / CLHEP::mole);
    G4Element* Br = new G4Element("Bromine", "Br", 35., 79.904 * CLHEP::g / CLHEP::mole);

    // Add vacuum
    materials_["vacuum"] = new G4Material("Vacuum", 1, 1.008 * CLHEP::g / CLHEP::mole, CLHEP::universe_mean_density);

    // Create Epoxy material
    G4Material* Epoxy = new G4Material("Epoxy", 1.3 * CLHEP::g / CLHEP::cm3, 3);
    Epoxy->AddElement(H, 44);
    Epoxy->AddElement(C, 15);
    Epoxy->AddElement(O, 7);
    materials_["epoxy"] = Epoxy;

    // Create Carbon Fiber material:
    G4Material* CarbonFiber = new G4Material("CarbonFiber", 1.5 * CLHEP::g / CLHEP::cm3, 2);
    CarbonFiber->AddMaterial(Epoxy, 0.4);
    CarbonFiber->AddElement(C, 0.6);
    materials_["carbonfiber"] = CarbonFiber;

    // Create PCB G-10 material
    G4Material* GTen = new G4Material("G10", 1.7 * CLHEP::g / CLHEP::cm3, 3);
    GTen->AddMaterial(nistman->FindOrBuildMaterial("G4_SILICON_DIOXIDE"), 0.773);
    GTen->AddMaterial(Epoxy, 0.147);
    GTen->AddElement(Cl, 0.08);
    materials_["g10"] = GTen;

    // Create solder material
    G4Material* Solder = new G4Material("Solder", 8.4 * CLHEP::g / CLHEP::cm3, 2);
    Solder->AddElement(Sn, 0.63);
    Solder->AddElement(Pb, 0.37);
    materials_["solder"] = Solder;

    // Create CeBr3
    G4Material* CeBr3 = new G4Material("CeBr3", 5.18 * CLHEP::g / CLHEP::cm3, 2);
    CeBr3->AddElement(Ce, 1);
    CeBr3->AddElement(Br, 3);
    materials_["cebr3"] = CeBr3;
    // Material properties tables of CeBr3
    // Provided by Scionix
    G4double cebr3[] = {320, 330, 340, 345, 350, 355, 360, 365, 370, 371, 372, 375, 377.5, 380, 385,
                        389, 390, 391, 392, 395, 400, 405, 410, 415, 420, 425, 430, 435,   440};
    G4double conv_factor = 0.0012398;
    const G4int size = sizeof(cebr3) / sizeof(G4double);
    G4double cebr3_ch[size] = {0};
    for(auto i = 0; i < size; i++) {
        cebr3_ch[i] = (conv_factor) / cebr3[i];
    }
    // Provided by Scionix
    G4double cebr3_SC[] = {0.000, 0.000, 0.001, 0.030, 0.098, 0.199, 0.434, 0.779, 0.957, 0.961,
                           0.955, 0.906, 0.866, 0.849, 0.823, 0.804, 0.796, 0.781, 0.760, 0.696,
                           0.541, 0.370, 0.224, 0.120, 0.059, 0.029, 0.012, 0.004, 0.001};
    assert(sizeof(cebr3_SC) == sizeof(cebr3_ch));

    // info from
    // https://www.researchgate.net/figure/The-calculated-optical-constants-of-CeCl-3-and-CeBr-3-a-refractive-index-b_fig7_256855384
    G4double cebr3_RIND[] = {2.5,  2.48, 2.46, 2.55, 2.42, 2.40, 2.41, 2.42, 2.42, 2.42, 2.42, 2.43, 2.43, 2.43, 2.43,
                             2.44, 2.44, 2.44, 2.44, 2.44, 2.44, 2.45, 2.46, 2.47, 2.48, 2.49, 2.50, 2.51, 2.52};
    assert(sizeof(cebr3_RIND) == sizeof(cebr3_ch));
    // Info from https://www.advatech-uk.co.uk/cebr3.html -> Mass attenuation coeff = abs_length
    G4double cebr3_ABSL[] = {10000 * CLHEP::cm, 10000 * CLHEP::cm, 10000 * CLHEP::cm, 10000 * CLHEP::cm, 10000 * CLHEP::cm,
                             10000 * CLHEP::cm, 10000 * CLHEP::cm, 10000 * CLHEP::cm, 10000 * CLHEP::cm, 10000 * CLHEP::cm,
                             10000 * CLHEP::cm, 10000 * CLHEP::cm, 10000 * CLHEP::cm, 10000 * CLHEP::cm, 10000 * CLHEP::cm,
                             10000 * CLHEP::cm, 10000 * CLHEP::cm, 10000 * CLHEP::cm, 10000 * CLHEP::cm, 10000 * CLHEP::cm,
                             10000 * CLHEP::cm, 10000 * CLHEP::cm, 10000 * CLHEP::cm, 10000 * CLHEP::cm, 10000 * CLHEP::cm,
                             10000 * CLHEP::cm, 10000 * CLHEP::cm, 10000 * CLHEP::cm, 10000 * CLHEP::cm};
    assert(sizeof(cebr3_ABSL) == sizeof(cebr3_ch));
    auto CeBr3_mt = new G4MaterialPropertiesTable();
    CeBr3_mt->AddProperty("FASTCOMPONENT", cebr3_ch, cebr3_SC, size);
    CeBr3_mt->AddProperty("RINDEX", cebr3_ch, cebr3_RIND, size);
    CeBr3_mt->AddProperty("ABSLENGTH", cebr3_ch, cebr3_ABSL, size);
    // Info https://www.ipen.br/biblioteca/cd/ieee/2004/DATA/3R04-1.PDF
    CeBr3_mt->AddConstProperty("SCINTILLATIONYIELD", 68000. / CLHEP::MeV);
    // ??
    CeBr3_mt->AddConstProperty("RESOLUTIONSCALE", 1.0);
    // Info  https://www.degruyter.com/downloadpdf/j/nuka.2017.62.issue-3/nuka-2017-0032/nuka-2017-0032.pdf
    CeBr3_mt->AddConstProperty("FASTTIMECONSTANT", 18. * CLHEP::ns);
    // https://www.berkeleynucleonics.com/sites/default/files/products/resources/cebr3_fast_timing_study_below_120_ps.pdf
    CeBr3_mt->AddConstProperty("FASTSCINTILLATIONRISETIME", 0.7 * CLHEP::ns);
    // Only fast component so yield = 1
    CeBr3_mt->AddConstProperty("YIELDRATIO", 1.0);
    CeBr3->SetMaterialPropertiesTable(CeBr3_mt);
    // ??
    // CeBr3->GetIonisation()->SetBirksConstant(0.126 * CLHEP::mm / CLHEP::MeV);
}